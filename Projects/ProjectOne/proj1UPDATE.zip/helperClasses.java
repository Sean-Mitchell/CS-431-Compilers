package Starter;

class Token {
	int type;
	String value;
	String token;
	public Token(int type, String value, String token) {
		this.type = type;
		this.value = value;
		this.token = token;
	}
}